const ACCOUNT_API_URL = "http://localhost:3000/accounts";
const TRANSACTION_TYPE = {
  DEPOSIT: "Deposit",
  WITHDRAW: "Withdraw",
  TRANSFER: "Transfer",
};

const table = document.querySelector('.newAcct__table');


const addNewAcct = () => {
    const newAcct = document.querySelector(".newAcct__insert > input").value;
  
    //POST Account
    return $.ajax({
      url: ACCOUNT_API_URL,
      method: "POST",
      contentType: "application/json",
      dataType: "json",
      data: JSON.stringify({
        newAccount: newAcct,
      }),
      success: (res) => {
        // create new row with account id and balance 0
        const newRow = document.createElement("tr");
        const newAcctTd = document.createElement("td");
        newAcctTd.innerText = res.username;
        const newBalTd = document.createElement("td");
        newBalTd.innerText = "0";
        newRow.appendChild(newAcctTd);
        newRow.appendChild(newBalTd);
        table.appendChild(newRow);
        
        // clear input field
        document.querySelector(".newAcct__insert > input").value = "";
      },
      error: (error) => {
        if (error.status === 400) alert("Fail to create new Account");
        throw new Error("Fail to create new Account");
      },
    });
  };
  
//when page reloaded get datas and make it list 
const getAllAccounts = () => {
    return $.ajax({
      url: ACCOUNT_API_URL,
      method: "GET",
      dataType: "json",
    }).then((res) => {
      for (let i = 0; i < res.length; i++) {
        const newTr = document.createElement("tr");
        const newAcct = document.createElement("td");
        newAcct.innerText = res[i].username;
        const newBal = document.createElement("td");
        newBal.textContent = 0;
  
        // Add td
        newTr.appendChild(newAcct);
        newTr.appendChild(newBal);
        // Add tr
        table.appendChild(newTr);
      }
    }); 
  };
 
  const updateBalance = () => {
    // Initialize balance object
    const balance = {};
  
    // GET account data
    return $.ajax({
      url: ACCOUNT_API_URL,
      method: "GET",
      dataType: "json",
      success: (res) => {
        // Loop through account data
        res.forEach(account => {
          console.log("account", account)
          const accountId = account.id;
          const accountName = account.username;
          const accountBalance = calculateBalance(accountId, account.transactions);
          balance[accountName] = accountBalance;
          // console.log(accountBalance);
        });
  
        // Update balance values in table
        // Get all the account rows in the table
        var accountRows = $(".newAcct__table tr");
  
        // Loop through each row and update the balance value
        accountRows.each(function (index, row) {
          var accountId = $(row).find("td:first-child").text();
          var accountBalance = balance[accountId];
          $(row).find("td:last-child").text(accountBalance);
        });
  
        // Return balance object
        return balance;
      },
    });
  };
  
  const calculateBalance = (id, transactions) => {
    console.log(transactions);
    return transactions.reduce((acc, transaction) => {
      console.log("reduce", acc);
      switch (transaction.type) {
        case "Deposit":
          return acc + parseFloat(transaction.amount);
        case "Withdraw":
          return acc - parseFloat(transaction.amount);
        case "Transfer":
          if (transaction.accountIdTo === id) {
            return acc + parseFloat(transaction.amount);
          } else {
            return acc - parseFloat(transaction.amount);
          }
        }
      }, 0);
  };
  
  

export {addNewAcct, getAllAccounts,updateBalance};
