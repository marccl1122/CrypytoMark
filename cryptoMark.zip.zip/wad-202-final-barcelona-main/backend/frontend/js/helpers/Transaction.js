import { getCategories } from "./Category.js";

const ACCOUNT_API_URL = "http://localhost:3000/accounts";
const TRANSACTION_API_URL = "http://localhost:3000/transactions";
const TRANSACTION_TYPE = {
  DEPOSIT: "Deposit",
  WITHDRAW: "Withdraw",
  TRANSFER: "Transfer",
};

const transactionDomOperation = () => {
  $(".transfer-from").hide();
  $(".transfer-to").hide();
  $('input[name="transaction-type"]').change(() => {
    const selected = $('input[name="transaction-type"]:checked').val();
    if (selected === TRANSACTION_TYPE.DEPOSIT || selected === TRANSACTION_TYPE.WITHDRAW) {
      $(".transfer-from").hide();
      $(".transfer-to").hide();
      $(".transfer-account").show();
    }
    if (selected === TRANSACTION_TYPE.TRANSFER) {
      $(".transfer-from").show();
      $(".transfer-to").show();
      $(".transfer-account").hide();
    }
  });
};

const addTransaction = () => {
  const selectedType = $('input[name="transaction-type"]:checked').val();
  let accountId = Number($("#select-account").val());
  let accountIdFrom = Number($("#select-account-from").val());
  let accountIdTo = Number($("#select-account-to").val());

  if (selectedType === TRANSACTION_TYPE.TRANSFER) {
    accountId = null;
    if (accountIdFrom === accountIdTo) {
      alert("Failed to add transaction. Select different accounts for acount from and acount to.");
      throw new Error("Failed to add transaction");
    }
  } else if (selectedType === TRANSACTION_TYPE.DEPOSIT || selectedType === TRANSACTION_TYPE.WITHDRAW) {
    accountIdFrom = null;
    accountIdTo = null;
  }

  return $.ajax({
    url: TRANSACTION_API_URL,
    method: "POST",
    dataType: "json",
    data: {
      newTransaction: JSON.stringify({
        accountId: accountId,
        accountIdFrom: accountIdFrom,
        accountIdTo: accountIdTo,
        type: selectedType,
        amount: $("#transaction-amount").val(),
        categoryId: Number($("#select-category").val()),
        description: $("#transaction-description").val(),
      }),
    },
    success: (response) => {
      $("#transaction-amount").val("");
      $("#transaction-description").val("");
    },
    error: (error) => {
      if (error.status === 400) alert("Invalid transaction. Fill in all values.");
      throw new Error("Failed to add transaction");
    },
  });
};

const getAccounts = () => {
  return $.ajax({
    url: ACCOUNT_API_URL,
    method: "GET",
    dataType: "json",
  }).fail((error) => {
    throw new Error("Failed to get accounts");
  });
};

const appendAccounts = (account) => {
  const option = `<option class="select-account-item" value=${account.id}>${account.username}</option>`;
  $("#select-account").append(option);
  $("#select-account-from").append(option);
  $("#select-account-to").append(option);
  return account;
};

const setInitialAccounts = () => {
  getAccounts().done((data) => {
    data.forEach((accountItem) => appendAccounts(accountItem));
  });
};

const getTransactions = () => {
  return $.ajax({
    url: TRANSACTION_API_URL,
    method: "GET",
    dataType: "json",
  }).fail((error) => {
    throw new Error("Failed to get transactions");
  });
};

const appendTransaction = (transaction, accounts, categories) => {
  const username = accounts.find((account) => account.id === transaction.accountId).username;
  let usernameFrom = "-";
  let usernameTo = "-";
  if (transaction.type === TRANSACTION_TYPE.TRANSFER) {
    usernameFrom = accounts.find((account) => account.id === transaction.accountIdFrom).username;
    usernameTo = accounts.find((account) => account.id === transaction.accountIdTo).username;
  }
  const category = categories.find((category) => category.id === transaction.categoryId).name;
  const row = $("<tr></tr>");
  $("<td></td>").html(transaction.id).appendTo(row);
  $("<td></td>").html(username).appendTo(row);
  $("<td></td>").html(transaction.type).appendTo(row);
  $("<td></td>").html(category).appendTo(row);
  $("<td></td>").html(transaction.description).appendTo(row);
  $("<td></td>").html(transaction.amount).appendTo(row);
  $("<td></td>").html(usernameFrom).appendTo(row);
  $("<td></td>").html(usernameTo).appendTo(row);
  row.appendTo("#transaction-list");
};

const setInitialTransaction = () => {
  // get categories
  getCategories().done((categories) => {
    // get accounts
    getAccounts().done((accounts) => {
      // get transactions
      getTransactions().done((transactions) => {
        if (transactions.length === 0) return;
        transactions.forEach((transaction) => {
          transaction.forEach((transactionItem) => appendTransaction(transactionItem, accounts, categories));
        });
      });
    });
  });
};

export {
  transactionDomOperation,
  addTransaction,
  getAccounts,
  appendAccounts,
  setInitialAccounts,
  appendTransaction,
  setInitialTransaction,
};



