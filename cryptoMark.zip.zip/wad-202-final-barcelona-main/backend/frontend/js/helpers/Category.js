const CATEGORY_API_URL = "http://localhost:3000/categories";

const addCategory = () => {
  return $.ajax({
    url: CATEGORY_API_URL,
    method: "POST",
    contentType: "application/json",
    dataType: "json",
    data: JSON.stringify({
      newCategory: $("#category-name").val(),
    }),
    success: (response) => {
      $("#category-name").val("");
    },
    error: (error) => {
      alert("Failed to add category. Category name must be filled");
      throw new Error("Failed to add category");
    },
  });
};

const getCategories = () => {
  return $.ajax({
    url: CATEGORY_API_URL,
    method: "GET",
    dataType: "json",
  }).fail((error) => {
    throw new Error("Failed to get categories");
  });
};

const appendCategory = (category) => {
  $("#select-category").append(`<option class="select-category-item" value=${category.id}>${category.name}</option>`);
  return category;
};

const setInitialCategories = () => {
  getCategories().done((data) => {
    data.forEach((categoryItem) => appendCategory(categoryItem));
  });
};

export { addCategory, getCategories, appendCategory, setInitialCategories };
