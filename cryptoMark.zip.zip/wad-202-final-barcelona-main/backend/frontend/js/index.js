import { addCategory, getCategories, appendCategory, setInitialCategories } from "./helpers/Category.js";
import {
  transactionDomOperation,
  addTransaction,
  getAccounts,
  appendAccounts,
  setInitialAccounts,
  appendTransaction,
  setInitialTransaction,
} from "./helpers/Transaction.js";

import { addNewAcct, getAllAccounts, updateBalance } from "./helpers/Account.js";

$(() => {
  // Category
  setInitialCategories();
  $("#add-category").click(() => {
    addCategory().done((data) => {
      appendCategory(data);
    });
  });

  // Transaction
  transactionDomOperation();
  setInitialAccounts();
  $("#add-transaction").click(() => {
    addTransaction().done((data) => {
      // get categories
      getCategories().done((categories) => {
        // get accounts
        getAccounts().done((accounts) => {
          appendTransaction(data[0], accounts, categories);
        });
      });
    });
    updateBalance();
  });

  setInitialTransaction();
});

const newAccBtn = document.querySelector(".newAcct__insert > button");
$(newAccBtn).click(() => {
  addNewAcct().done((data) => {
    appendAccounts(data);
  });
  // getAllAccounts();
});

$(window).on("load", () => {
  getAllAccounts();
  updateBalance();
});

